Menedżer zadań w formularzach WinForm .NET Framework przy użyciu wątku.
 
W głównej formie aplikacji w siatce musisz wyświetlić stale aktualizowaną listę
procesy wykonywalne.

Należy zapewnić możliwość uzyskania rozszerzonej informacji dla wybranych
proces.

Odbieranie informacji o procesach powinno odbywać się w osobnym wątku, może tak być
wstrzymaj i kontynuuj.

Kod aplikacji musi być bezpieczny zarówno pod względem wyjątków, jak i podczas pracy z nim
strumienie.

Podczas pracy musisz rejestrować wszystkie zdarzenia, które mają miejsce w pliku tekstowym.
(na przykład żądanie użytkownika dotyczące informacji o procesie, jego wstrzymaniu i
kontynuacja aktualizacji listy procesów, pojawienie się nowego procesu na liście, zniknięcie
proces z listy itp.)

Aby rozwiązać problem, możesz użyć zarówno standardowych kontrolek systemu Windows, jak i dowolnych
komponenty stron trzecich.

Zwróć szczególną uwagę na interfejs użytkownika, powinien być wygodny i schludny,
pomimo minimalizmu projektu.